# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some Oxlint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the Oxlint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and Oxlint's TypeScript related rules in your project.
# 🚀 Cyber Dodge – Neon Arcade Survival Game

A fast-paced futuristic arcade survival game built using **React and JavaScript**.

Control your neon spaceship, dodge falling obstacles, collect energy orbs, activate power-ups, and survive as long as possible to achieve the highest score!

## 🎮 Features

- 🚀 Futuristic neon spaceship gameplay.
- 🔴 Multiple falling obstacles with different behaviors.
- 💎 Collectible cyan energy orbs.
- ⚡ Three temporary power-ups.
- 🛡️ Shield power-up to absorb one collision.
- ⏱️ Slow-motion power-up to reduce obstacle speed.
- ✨ Double-score power-up.
- 🔥 Combo system with bonus points.
- ❤️ Three lives per game.
- 🏆 High-score tracking using browser Local Storage.
- 🔊 Procedurally generated sound effects.
- 📱 Mobile-friendly touch controls.
- ⏸️ Pause and resume functionality.
- 🌌 Cyberpunk-inspired neon visual effects.

## 🕹️ How to Play

Your mission is simple: **Dodge obstacles, collect orbs, and survive as long as possible!**

### Controls

| Action | Control |
|---|---|
| Move Left | Left Arrow / A |
| Move Right | Right Arrow / D |
| Mobile Left | Tap left side |
| Mobile Right | Tap right side |
| Pause / Resume | Escape |

### Obstacles to Avoid

- 🔴 Red Blocks – Standard falling obstacles.
- 🟣 Purple Blocks – Fast-moving obstacles.
- 🟠 Orange Blocks – Large obstacles.
- 🟢 Green Blocks – Obstacles that move sideways.

### Collectibles

- 🔵 Cyan Orbs – Collect to earn points and build combos.
- 🛡️ Shield – Absorbs one collision.
- ⏱️ Slow – Reduces obstacle speed.
- ✨ Double – Doubles points earned.

Power-ups remain active for 5 seconds.

## ⚙️ Technologies Used

- React 19
- JavaScript (ES6+)
- Vite
- HTML5
- CSS3
- Web Audio API
- Browser Local Storage

## 💻 Installation & Setup

### 1. Download the Project

Download or clone this repository to your computer.

### 2. Install Node.js

Make sure Node.js and npm are installed.

### 3. Open the Project Folder

Open the project folder in VS Code.

### 4. Install Dependencies

Open the terminal and run:

```bash
npm install
```

### 5. Start the Development Server

```bash
npm run dev
```

### 6. Open the Game

Open the local URL displayed in your terminal, usually:

```text
http://localhost:5173
```

Enjoy playing Cyber Dodge!

## 📦 Build for Production

To create an optimized production build:

```bash
npm run build
```

To preview the production build:

```bash
npm run preview
```

## 🏆 Game Objective

Survive for as long as possible, avoid obstacles, collect energy orbs, build combos, and beat your previous high score!

**Can you survive the Cyber Dodge challenge?** ⚡

---



